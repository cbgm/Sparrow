@echo off
cd /d "%~dp0"
start "" powershell.exe -STA -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Start-SparrowServer.ps1"
