# Message, invitation and transport flow

This page connects the current client layers from UI to encrypted network delivery.

## Direct send

```mermaid
sequenceDiagram
    participant VM as DirectConversationActionsController
    participant ORCH as ConversationOrchestrator
    participant WF as SendDirectMessageWorkflow
    participant AUTH as RequireDirectChatAuthorizationUseCase
    participant DEL as DeliverDirectMessageWorkflow
    participant DB as Room
    participant OUT as ProtocolOutbox
    participant RUN as DefaultOutboxRunner
    participant SEND as OutgoingPacketSender
    participant MB as MailboxOutgoingWireSender

    VM->>ORCH: awaitResult(DirectConversationCommand.SendMessage)
    ORCH->>WF: blocked? pending identity change?
    WF->>AUTH: CheckAuthorization step
    alt authorized
        WF->>DEL: DeliverMessage step
        DEL->>DB: persist message
        DEL->>OUT: enqueue encrypted packet work
        RUN->>SEND: process persisted packet
        SEND->>MB: put into the contact's mailbox (or invitation mailbox) through the circuit
    else not authorized
        WF->>WF: StoreWaitingDirectMessage (release lock): authorized now?
        alt still not authorized
            WF->>DB: persist WAITING_FOR_AUTHORIZATION (optionally request reauthorization)
        else authorized meanwhile
            WF->>DEL: DeliverMessage step
        end
    end
```

A send takes no lock, so a message to an authorized contact is stored and shown at once even while an earlier
message to the same contact still uploads its attachments. Only storing a waiting message holds the contact's release
lock and checks the authorization again under it, so a release running at the same time never misses it. Editing or
deleting a sent message takes no lock either; only a message that was never sent is edited or deleted under the
release lock, so it is never released with its old text or written back. In groups, editing or deleting a message the
members have is sent right away; only a message nobody has received yet waits for the group send lock, so a running
flush sends the new text or nothing. See [Locking](../architecture/conversation-orchestration.md#locking).

A queued Direct message is released by `ReleaseWaitingDirectMessagesWorkflow` (via `ActivateAuthorizedConversationWorkflow`) only after orchestration establishes fresh authorization. There is no plaintext fallback.

Retrying a failed Direct message (`RetryDirectMessageWorkflow`) resends its packet when the outbox still has it and otherwise creates a new packet, for example when the outbox insert failed. A send interrupted between storing the message and queuing its packet (the app was closed or crashed) is found at the next app start (`RecoverInterruptedDirectSendsUseCase`) and marked failed, so the user can retry it.

## Incoming delivery

```mermaid
sequenceDiagram
    participant MB as MailboxArrivalListener / MailboxPendingSynchronizer
    participant IP as IncomingEnvelopeProcessorImpl
    participant H as IncomingTransportMessageHandler
    participant ROUTE as RouteIncomingPacketWorkflow
    participant CTRL as ControlPacketDispatcher
    participant GRP as GroupPacketDispatcher

    MB->>IP: envelope from a mailbox (an invitation letter only once its sender is proven)
    IP->>H: decrypt/decode packet
    H->>ROUTE: IncomingPacket
    ROUTE->>ROUTE: direct message: ReceiveDirectMessageWorkflow / receipt: ApplyDeliveryEventWorkflow
    ROUTE->>GRP: group packets -> ReceiveGroup*Workflow
    ROUTE->>CTRL: identity/invite packets -> ReceiveContact*/ReceiveGroupInvite*Workflow
```

A packet that is not allowed or invalid (an edit by someone other than the sender, a vote on a closed poll, an expense change by a non-creator, an expired group JOIN, a message ID that belongs to another message) is rejected with `IncomingMessageRejectedException`: its envelope is acknowledged and dropped instead of being redelivered until it expires. Failures that can succeed later (database, network, an expense revision whose original has not arrived) keep the envelope for redelivery. A redelivered direct or group message keeps its stored row, so edits, deletions and the read state applied since are not undone.

Delivery paths do not guarantee order: after a reconnect, an edit, delete, reaction or poll operation can
arrive before the message it refers to. Such an operation is parked locally and applied right after the
message is stored; it is deleted after 7 days if the message never arrives
([Conversation orchestration](../architecture/conversation-orchestration.md#operations-that-overtake-their-message)).
Edits are ordered by their edit time, not by arrival: an older edit that arrives after a newer one is ignored
(equal times keep the stored text).

Whole packets can also arrive too early: a group packet before the welcome of its epoch (or before the first
welcome of a group the user just joined), or a direct message or operation of a contact whose invitation is
still in flight (the accepter sends `ContactInviteAccepted` and then a message, and the message is processed
first). `RouteIncomingPacketWorkflow` then fails with `IncomingPacketDeferredException`;
`IncomingEnvelopeProcessorImpl` parks the envelope and acknowledges it, because an unacknowledged live envelope
is lost and a mailbox envelope would be redelivered until it expires. After each envelope that was handled, the
parked envelopes whose wait is met are processed again in arrival order
([Conversation orchestration](../architecture/conversation-orchestration.md#packets-that-arrive-too-early)).
Messages of unknown, blocked or revoked contacts are still dropped.

## Direct invitation/authorization

The generic invitation row is owned by `:feature:invite`, the cryptographic exchange by `:feature:identity`, and the cross-feature sequence by the lifecycle workflows (`StartDirectInvitationWorkflow`, `HandleDirectInvitationResultWorkflow`, …) run by `OpenDirectConversationWorkflow` and `InvitationResultObserver`.

```mermaid
flowchart LR
    CONTACT[contact selection] --> OPEN[OpenDirectConversationWorkflow]
    OPEN --> FLOW[StartDirectInvitationWorkflow]
    FLOW --> ID[Identity exchange]
    FLOW --> INV[Invitation lifecycle]
    INV --> OBS[InvitationResultObserver]
    OBS --> FLOW2[HandleDirectInvitationResultWorkflow /<br/>RecoverAcceptedDirectInvitationWorkflow]
    FLOW2 --> CHAT[ActivateAuthorizedConversationWorkflow]
    CHAT --> REL[ReleaseWaitingDirectMessagesWorkflow]
```

Explicit recovery/reconnection is documented separately in [Identity recovery](identity-recovery.md).

## Group send

`SendGroupMessageWorkflow` validates active membership, obtains current recipients from Membership, encrypts for the current Group epoch and queues one packet per active recipient (`CheckMembership -> FindRecipients -> [FlushQueuedMessages] -> StoreMessage -> EncryptMessage -> SaveRecipientStates -> EnqueuePackets`). Group security state is not inferred from the invitation table.

## Offline mailbox

Every packet goes into a mailbox: `OutgoingPacketSender` hands it to `MailboxOutgoingWireSender`, which uses the recipient's mailbox route when the app has it and the recipient's invitation mailbox otherwise. Client mailbox lifecycle is implemented around `DefaultMailboxCoordinator`, `DefaultMailboxCapabilityLifecycle`, `MailboxRouteProvisioner`, `MailboxPendingSynchronizer` and `MailboxRepositoryImpl`.

`MailboxRouteProvisioner` decides from the freshly verified, signed node directory, never from a socket failure:

- **Moved node:** a node keeps its node ID when its address changes (for example a new public IP). Saved mailbox credentials whose node ID is in the directory under a new address switch to the node's new mailbox access endpoint. A mailbox whose delivery route still points to the old address is renewed and the new route is shared with the contact (`MailboxRoutePacket`), because contacts keep delivering to the old address until then.
- **Retired node:** a node ID that is missing from the verified directory means the old mailbox is gone; a replacement is saved without revoking the old one.
- **Unreachable or refusing node:** `DefaultMailboxCapabilityLifecycle.revokeForContact` deletes the remote route and marks the local mailbox revocation pending. If the revocation fails for any reason, it stays pending instead of failing the caller (for example deleting a chat or approving an identity change); provisioning retries every pending revocation, and one that keeps failing does not hold up the others. A node that answers 404, 410 or 401 no longer has the mailbox, so the revocation counts as done.
- **Renewal:** the replacement is saved and its route shared (`MailboxRoutePacket`, queued in the outbox), but the old mailbox is not revoked yet: it may still hold envelopes, and the contact keeps sending to the old route until the packet arrived. The old credential becomes a *retiring* credential (`retiring_mailbox_credentials`, one row per route, saved together with the replacement in one transaction). It stays readable until it expires; after its expiry provisioning revokes it once the pending synchronization emptied it (or after a grace period of 7 days). A revocation that fails because the node is unreachable is retried by the next provisioning; any other failure drops the local copy and the node expires the mailbox itself. A retiring mailbox on a retired node is dropped without revocation.
- **Eligibility:** `GetMailboxContactStatesUseCase` (Contacts) gives a contact a mailbox only with a mutual identity and a routing ID, and only while it is someone we still talk to: a direct conversation with an established identity exchange, or an active group we share (group packets also arrive through the mailbox). A contact whose direct chat was deleted (exchange revoked, conversation removed, mailbox revoked) therefore never gets a fresh mailbox or route, even though it stays MUTUAL.
- **Blocked contact / deleted chat:** `revokeForContact` revokes the current and every retiring mailbox of the contact; `revokeAll` and the pending-revocation retry cover retiring mailboxes too.

`MailboxPendingSynchronizer` processes every local mailbox, current and retiring (except those whose revocation is pending). An envelope that fails stays in its mailbox for the next sync and does not stop the envelopes behind it or the other mailboxes; a mailbox that cannot be read is skipped. Rejected envelopes are acknowledged and dropped.

A packet for a device whose mailbox route the app does not have yet (a first invitation, or the answers before the contact's route arrived) goes into the device's invitation mailbox instead, as a letter signed with the device key and sealed for the recipient; see [Invitation mailboxes](transport.md#invitation-mailboxes).

The server `mailbox` service stores opaque encrypted envelopes behind recipient-selected capabilities. Nothing wakes the device; the app waits at its mailboxes while it runs.

## Delivery/read receipts

Protocol receipts are routed by `RouteIncomingPacketWorkflow` to `ApplyDeliveryEventWorkflow`; outbox progress reaches the same workflow through `OutboxDeliveryStateRouter`. Direct and Group maintain distinct recipient/delivery state logic (`DirectMessageDeliveryStateMachine`, `GroupMessageDeliveryStateMachine`, `DirectMessageDeliveryRepository` and `GroupRecipientDeliveryRepository` in `:feature:conversationorchestration:delivery`), while generic outbox execution remains in `:feature:messaging`.
