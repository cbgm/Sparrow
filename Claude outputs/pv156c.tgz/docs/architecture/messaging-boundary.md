# Messaging boundary

Messaging crosses several modules, but the current code has a deliberate split between **generic queue execution** and **conversation-aware orchestration**.

| Concern | Owner | Representative classes |
|---|---|---|
| Packet contracts/codecs | `:protocol` | `SparrowPacket`, `KotlinxPacketCodec`, packet data classes |
| Persistent outbox contracts/state | `:protocol` | `ProtocolOutbox`, outbox state/event types |
| Persistent outbox storage | `:data:database` | `ProtocolOutboxEntity`, `ProtocolOutboxDao`, `ProtocolOutboxFailureEventEntity` |
| Generic outbox execution | `:feature:messaging` | `DefaultOutboxRunner`, `DefaultOutboxProcessor` |
| Send policy, delivery state, mailbox receiving | `:feature:conversationorchestration:delivery` | `MailboxPendingSynchronizer`, `MailboxArrivalListener`, `OutgoingPacketSender`, `OutgoingRecipientRoutingResolver`, `OutgoingTransportPayloadFactory`, `OutboxDeliveryStateRouter`, `ApplyDeliveryEventWorkflow` |
| Conversation write semantics | `:feature:conversationorchestration:message` / `membership` / `lifecycle` | `SendDirectMessageWorkflow`, `DeliverDirectMessageWorkflow`, `SendGroupMessageWorkflow`, group administration and invitation workflows |
| Incoming packet handling | `:feature:conversationorchestration:incoming` | `IncomingEnvelopeProcessorImpl`, `IncomingTransportMessageHandler`, `RouteIncomingPacketWorkflow`, `GroupPacketDispatcher`, `ControlPacketDispatcher`, `Receive*Workflow` |
| Conversation presentation/read side | `:feature:chats` | ViewModels/controllers, read repositories, observe use cases; writes via `ConversationOrchestrator` |
| Invitation lifecycle | `:feature:invite` | `InvitationRepositoryImpl`, `InvitationLifecycleDataSource`, `InvitationResultObserver` (consumer in orchestration) |
| Identity/trust/recovery | `:feature:identity` | `IdentityExchangeDataSource`, pending identity changes, approved reconnection repositories/use cases |
| Group membership/security | `:feature:membership` | `GroupMembershipStateMachine`, `GroupSecurityManager`, membership use cases |
| Wire/discovery | `:feature:transport` | `HomeNodeConnection`, `CircuitRunner`, `MailboxOutgoingWireSender`, mailbox/control-plane clients |

## Outgoing boundary

```mermaid
sequenceDiagram
    participant CHAT as Send*Workflow (message)
    participant OB as ProtocolOutbox
    participant RUN as DefaultOutboxRunner
    participant PROC as DefaultOutboxProcessor
    participant SEND as OutgoingPacketSender
    participant POLICY as identity/routing/payload policy
    participant WIRE as SendEncodedTransportUseCase
    participant TR as feature:transport

    CHAT->>OB: persist packet
    RUN->>PROC: process pending item
    PROC->>SEND: send(ProtocolOutboxItem)
    SEND->>POLICY: decode, identity-review gate, encrypt, resolve routing
    SEND->>WIRE: encoded transport payload + routing ID
    WIRE->>TR: wire delivery
```

`OutgoingPacketSender` re-checks pending remote identity changes at the final transport boundary, preventing already-persisted Direct application packets from being sent against an old trust state while the user reviews replacement keys.

`OutgoingRecipientRoutingResolver` uses contact routing use cases plus `GroupRoutingResolver`; invitations use invitation/bootstrap routing while established Group packets resolve through current Group routing state.

## Incoming boundary

```mermaid
sequenceDiagram
    participant RUN as MailboxPendingSynchronizer
    participant PROC as IncomingEnvelopeProcessorImpl
    participant H as IncomingTransportMessageHandler
    participant ROUTE as RouteIncomingPacketWorkflow
    participant WF as Receive*Workflow / dispatchers
    participant PH as DefaultProtocolPacketHandler

    RUN->>PROC: encrypted transport envelope from a mailbox
    PROC->>H: resolve sender, local keys
    H->>ROUTE: decrypted, decoded packet (WorkflowEngine)
    ROUTE->>WF: direct message / group packet / receipt / control packet
    WF->>PH: packets owned by other features (e.g. mailbox routes)
```

See [Conversation orchestration](conversation-orchestration.md) for the routing step chain.

## Message operations

Edits, deletes, reactions, poll votes and poll closes use the general `OperationMessage` / `MessageOperation` protocol. Direct chat accepts Edit/Delete/Reaction; Group additionally accepts PollVote/PollClose. These operations mutate existing messages and are processed through the same durable packet/outbox boundary rather than being stored as normal user-message content.

## Attachment/voice/link boundaries

Attachments own blob transfer/cache/storage and transcripts. Voice builds recording/playback/transcription on that attachment boundary. Link previews are fetched/cached separately from message encryption; the message contains the original text/URL, not trusted server-rendered HTML.

## Server boundary

Relays, circuits and mailboxes pass on or store opaque encrypted application payloads. Conversation authorization, Group membership and identity replacement decisions are client concerns.
