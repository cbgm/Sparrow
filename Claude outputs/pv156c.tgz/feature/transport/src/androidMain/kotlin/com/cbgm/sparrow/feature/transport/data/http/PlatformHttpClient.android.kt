package com.cbgm.sparrow.feature.transport.data.http

import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.serialization.kotlinx.json.json
import java.util.concurrent.TimeUnit
import kotlinx.serialization.json.Json

internal actual fun createPlatformHttpClient(json: Json): HttpClient =
    HttpClient(
        OkHttp
    ) {
        expectSuccess = true

        install(WebSockets)

        install(ContentNegotiation) {
            json(json)
        }

        engine {
            config {
                retryOnConnectionFailure(true)

                pingInterval(
                    20L,
                    TimeUnit.SECONDS
                )
            }
        }
    }
