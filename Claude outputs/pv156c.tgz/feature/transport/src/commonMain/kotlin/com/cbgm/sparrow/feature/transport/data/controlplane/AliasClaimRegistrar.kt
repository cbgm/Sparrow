package com.cbgm.sparrow.feature.transport.data.controlplane

import com.cbgm.sparrow.core.crypto.sealing.SealedMessageCipher
import com.cbgm.sparrow.core.crypto.signature.DetachedSignatureCrypto
import com.cbgm.sparrow.core.util.logging.SparrowLog
import com.cbgm.sparrow.core.util.phone.LocalPhoneNumberSource
import com.cbgm.sparrow.core.util.time.SystemClock
import com.cbgm.sparrow.feature.transport.data.TransportConfig
import com.cbgm.sparrow.feature.transport.data.directory.NodeDirectoryVerifier
import com.cbgm.sparrow.feature.transport.data.directory.SignedNodeDirectory
import com.cbgm.sparrow.feature.transport.data.route.relay.ControlPlaneRelayPolicy
import com.cbgm.sparrow.feature.transport.domain.model.ControlPlaneEndpoint
import com.cbgm.sparrow.feature.transport.domain.repository.InvitationMailboxRepository
import com.cbgm.sparrow.feature.transport.domain.repository.LocalBootstrapRoutingIdRepository
import com.cbgm.sparrow.protocol.identity.LocalEncryptionKeyPairSource
import com.cbgm.sparrow.protocol.identity.LocalSigningKeyPair
import com.cbgm.sparrow.protocol.identity.LocalSigningKeyPairSource
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlin.time.Duration.Companion.milliseconds

/**
 * Claims the device's phone alias at every Control Plane the user has (from the directory or added by hand), through
 * the relays of the Control Plane HTTP client ([com.cbgm.sparrow.feature.transport.data.route.relay.OnionRelayEngine]). For each
 * one it takes the presence directory's key from that Control Plane's own signed node directory, checked against its
 * pinned root, so neither a relay nor the gateway can swap in a key. A Control Plane whose root is not pinned yet is
 * skipped until the app has used it. Every claim names the device's invitation mailbox ([InvitationMailboxRepository])
 * with the identity's encryption key, so senders without a mailbox route of this device can still reach it.
 */
internal class AliasClaimRegistrar(
    private val controlPlaneHttpClient: HttpClient,
    private val controlPlaneConfiguration: ControlPlaneEndpointStore,
    private val relayPolicy: ControlPlaneRelayPolicy,
    private val directoryVerifier: NodeDirectoryVerifier,
    private val transportConfig: TransportConfig,
    private val signingKeyPairSource: LocalSigningKeyPairSource,
    private val signatureCrypto: DetachedSignatureCrypto,
    private val cipher: SealedMessageCipher,
    private val localBootstrapRoutingIdSource: LocalBootstrapRoutingIdRepository,
    private val localPhoneNumberSource: LocalPhoneNumberSource,
    private val phoneAttestationRemoteSource: PhoneAttestationRemoteSource,
    private val invitationMailbox: InvitationMailboxRepository,
    private val encryptionKeyPairSource: LocalEncryptionKeyPairSource,
    private val json: Json,
    private val now: () -> Long = SystemClock::nowEpochMilliseconds
) : PhoneAliasBinding {
    private val logger = SparrowLog.withTag("AliasClaimRegistrar")

    /** The aliases at least one Control Plane bound to this device at the latest claim; kept in memory only. */
    private val boundAliases = MutableStateFlow<Set<String>>(emptySet())

    override suspend fun awaitBound(
        alias: String,
        timeoutMilliseconds: Long
    ) {
        withTimeout(timeoutMilliseconds.milliseconds) { boundAliases.first { aliases -> alias in aliases } }
    }

    /** Returns the aliases at least one Control Plane bound to [routingId]. */
    suspend fun claim(routingId: String): Set<String> {
        val alias = localBootstrapRoutingIdSource.getLocalBootstrapRoutingId().getOrNull() ?: return emptySet()
        val attestation = phoneAttestation(routingId)
        val signingKeyPair = signingKeyPairSource.getSigningKeyPair().getOrThrow()
        val invitationRoute = invitationRoute()
        val results =
            controlPlaneConfiguration.endpoints.value.distinctBy(ControlPlaneEndpoint::baseUrl).map { endpoint ->
                claimAt(endpoint.baseUrl, routingId, ClaimContent(listOf(alias), attestation, invitationRoute), signingKeyPair)
            }
        // The token proves the number once; it is not used again after a Control Plane answered its attestation.
        if (attestation != null && results.any { result -> result != ClaimOutcome.Unreachable }) {
            localPhoneNumberSource.clearPhoneVerificationToken()
        }
        val bound = results.filterIsInstance<ClaimOutcome.Bound>()
        logger.info {
            "Phone alias bound at ${bound.count { it.aliases.isNotEmpty() }} of ${results.size} Control Planes " +
                "(${results.count { it == ClaimOutcome.Unreachable }} unreachable or without pinned root)"
        }
        return bound.flatMap(ClaimOutcome.Bound::aliases).toSet().also { aliases -> boundAliases.value = aliases }
    }

    /** The verifier's attestation while the sign-up token is still in memory; null without one or when it failed. */
    private suspend fun phoneAttestation(routingId: String): String? {
        val token = localPhoneNumberSource.getPhoneVerificationToken().getOrNull() ?: return null
        return phoneAttestationRemoteSource
            .attest(token, routingId)
            .onFailure { failure -> logger.warn { "Phone attestation failed: ${failure::class.simpleName}" } }
            .onFailure { failure -> failure.reportLimit() }
            .getOrNull()
    }

    /**
     * The invitation mailbox, renewed first when due. When it cannot be renewed now (offline), the newest one that
     * still lives: a claim without one would take it away from the presence directories.
     */
    private suspend fun invitationRoute(): InvitationRoute? {
        val mailbox =
            invitationMailbox
                .current()
                .onFailure { failure -> logger.warn { "Invitation mailbox not renewed: ${failure::class.simpleName}" } }
                .getOrNull()
                ?: invitationMailbox.receiving().getOrNull()?.firstOrNull()
                ?: return null
        return InvitationRoute(mailbox.deliveryRoute, encryptionKeyPairSource.getEncryptionKeyPair().getOrThrow().publicKey)
    }

    private suspend fun Throwable.reportLimit() {
        if (this is PhoneVerificationLimitReachedException) localPhoneNumberSource.reportPhoneVerificationLimitReached()
    }

    private suspend fun claimAt(
        baseUrl: String,
        routingId: String,
        content: ClaimContent,
        signingKeyPair: LocalSigningKeyPair
    ): ClaimOutcome =
        try {
            val key = aliasClaimKey(baseUrl)
            if (key == null) {
                ClaimOutcome.Unreachable
            } else {
                val sealed = sealedClaim(routingId, content, signingKeyPair, key)
                val result =
                    controlPlaneHttpClient
                        .post("${baseUrl.trimEnd('/')}/v1/alias-claims") {
                            contentType(ContentType.Application.Json)
                            setBody(json.encodeToString(AliasClaimRequest(sealed)))
                        }.body<AliasClaimResult>()
                ClaimOutcome.Bound(result.acceptedAliasIndexes.mapNotNull(content.aliases::getOrNull))
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (rejection: ClientRequestException) {
            logger.warn { "Alias claim refused with ${rejection.response.status.value}" }
            ClaimOutcome.Refused.takeIf { rejection.response.status == HttpStatusCode.Forbidden }
                ?: ClaimOutcome.Unreachable
        } catch (failure: Exception) {
            logger.warn { "Alias claim failed: ${failure::class.simpleName}" }
            ClaimOutcome.Unreachable
        }

    private suspend fun aliasClaimKey(baseUrl: String): ByteArray? {
        val root = relayPolicy.trustedRoot(baseUrl) ?: return null
        val directory =
            json.decodeFromString<SignedNodeDirectory>(
                controlPlaneHttpClient.get("${baseUrl.trimEnd('/')}/v1/nodes").bodyAsText()
            )
        directoryVerifier
            .verify(
                signedDirectory = directory,
                trustedRootNodeId = root,
                supportedProtocolVersion = transportConfig.supportedProtocolVersion,
                nowEpochMilliseconds = now()
            ).getOrThrow()
        return directory.directory.aliasClaimKey
    }

    private suspend fun sealedClaim(
        routingId: String,
        content: ClaimContent,
        signingKeyPair: LocalSigningKeyPair,
        presenceKey: ByteArray
    ): ByteArray {
        val unsigned =
            UnsignedAliasClaim(
                routingId = routingId,
                clientSigningPublicKey = signingKeyPair.publicKey,
                aliases = content.aliases,
                phoneAttestation = content.attestation,
                invitationRoute = content.invitationRoute,
                issuedAtEpochMilliseconds = now()
            )
        val signature =
            signatureCrypto
                .sign(json.encodeToString(unsigned).encodeToByteArray(), signingKeyPair.privateKey)
                .getOrThrow()
        val claim =
            AliasClaim(
                routingId = unsigned.routingId,
                clientSigningPublicKey = unsigned.clientSigningPublicKey,
                aliases = unsigned.aliases,
                phoneAttestation = unsigned.phoneAttestation,
                invitationRoute = unsigned.invitationRoute,
                issuedAtEpochMilliseconds = unsigned.issuedAtEpochMilliseconds,
                signature = signature
            )
        return cipher.seal(json.encodeToString(claim).encodeToByteArray(), presenceKey, ALIAS_CLAIM_CONTEXT).getOrThrow()
    }

    private class ClaimContent(
        val aliases: List<String>,
        val attestation: String?,
        val invitationRoute: InvitationRoute?
    )

    private sealed interface ClaimOutcome {
        class Bound(
            val aliases: List<String>
        ) : ClaimOutcome

        data object Refused : ClaimOutcome

        data object Unreachable : ClaimOutcome
    }
}
