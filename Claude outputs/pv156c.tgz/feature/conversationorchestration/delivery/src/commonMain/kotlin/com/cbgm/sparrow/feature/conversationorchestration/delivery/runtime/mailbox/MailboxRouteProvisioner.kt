package com.cbgm.sparrow.feature.conversationorchestration.delivery.runtime.mailbox

import com.cbgm.sparrow.core.util.logging.SparrowLog
import com.cbgm.sparrow.core.util.time.SystemClock
import com.cbgm.sparrow.feature.contacts.domain.repository.ContactBlocklistRepository
import com.cbgm.sparrow.feature.contacts.domain.usecase.GetMailboxContactStatesUseCase
import com.cbgm.sparrow.feature.conversationorchestration.delivery.runtime.mailbox.MailboxRouteProvisioner.Companion.RETIRING_GRACE_MILLISECONDS
import com.cbgm.sparrow.feature.transport.domain.model.NodeEndpoint
import com.cbgm.sparrow.feature.transport.domain.repository.LocalRoutingIdRepository
import com.cbgm.sparrow.feature.transport.domain.repository.MailboxRepository
import com.cbgm.sparrow.feature.transport.domain.repository.NodeEndpointRepository
import com.cbgm.sparrow.feature.transport.domain.rule.isRecoverableConnectivityFailure
import com.cbgm.sparrow.protocol.mailbox.LocalMailboxCredential
import com.cbgm.sparrow.protocol.mailbox.MailboxCapabilityLifecycle
import com.cbgm.sparrow.protocol.mailbox.MailboxRouteRepository
import com.cbgm.sparrow.protocol.outbox.ProtocolOutbox
import com.cbgm.sparrow.protocol.packet.MailboxRoutePacket
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MailboxRouteProvisioner(
    private val getMailboxContactStates: GetMailboxContactStatesUseCase,
    private val localRoutingIdSource: LocalRoutingIdRepository,
    private val nodeEndpointResolver: NodeEndpointRepository,
    private val mailboxRepository: MailboxRepository,
    private val mailboxRouteRepository: MailboxRouteRepository,
    private val mailboxCapabilityLifecycle: MailboxCapabilityLifecycle,
    private val contactBlocklistRepository: ContactBlocklistRepository,
    private val credentialFactory: MailboxCredentialFactory,
    private val protocolOutbox: ProtocolOutbox
) {
    private val provisioning = Mutex()
    private val log = SparrowLog.withTag("MailboxRouteProvisioner")

    /**
     * Provisions only when a contact that should have a mailbox has none yet, typically right after an invite: then
     * the route goes out at once instead of at the next connect, and messages to that contact use mailboxes from
     * then on. Cheap otherwise: no node is asked.
     */
    suspend fun provisionMissing(): Result<Int> =
        runCatching {
            val withMailbox = mailboxRouteRepository.allLocal().getOrThrow().mapTo(HashSet(), LocalMailboxCredential::contactId)
            val blocked = contactBlocklistRepository.getBlockedContactIds().getOrThrow()
            val missing =
                getMailboxContactStates().getOrThrow().any { state ->
                    state.isProvisioningEligible && state.contactId !in withMailbox && state.contactId !in blocked
                }
            if (missing) provision().getOrThrow() else 0
        }

    /** One provisioning at a time: the connect and the new-contact check must not create a mailbox twice. */
    suspend fun provision(): Result<Int> = provisioning.withLock { provisionNow() }

    private suspend fun provisionNow(): Result<Int> =
        runCatching {
            val now = SystemClock.nowEpochMilliseconds()
            // Node discovery validates signatures before returning a directory. It is
            // required before deciding that a saved mailbox belongs to an old server. Never infer this
            // from a socket failure: an offline node may still own pending envelopes.
            val availableNodes = resolveMailboxNodes()
            val node = availableNodes.first()
            followMovedNodes(availableNodes)
            mailboxCapabilityLifecycle.retryPendingRevocations()
                .onFailure { failure ->
                    if (failure is CancellationException) throw failure
                    if (failure.isRecoverableConnectivityFailure()) {
                        SparrowLog.withTag("MailboxRouteProvisioner").debug {
                            "Mailbox revocation deferred while its server is unreachable"
                        }
                    } else {
                        SparrowLog.diagnostic("MailboxRouteProvisioner", "Retrying mailbox revocations failed", failure)
                    }
                }
            revokeExpiredRetiringMailboxes(now, availableNodes)
            val blockedContactIds = contactBlocklistRepository.getBlockedContactIds().getOrThrow()
            var provisioned = 0

            getMailboxContactStates().getOrThrow().forEach { contactState ->
                val contactId = contactState.contactId
                if (contactId in blockedContactIds) {
                    log.info { "Contact $contactId is blocked: its mailbox is revoked" }
                    mailboxCapabilityLifecycle.revokeForContact(contactId)
                        .onFailure { failure ->
                            if (failure is CancellationException) throw failure
                            if (failure.isRecoverableConnectivityFailure()) {
                                SparrowLog.withTag("MailboxRouteProvisioner").debug {
                                    "Mailbox revocation deferred for blocked contact while its node is offline"
                                }
                            } else {
                                SparrowLog.diagnostic(
                                    "MailboxRouteProvisioner",
                                    "Mailbox revocation failed for $contactId",
                                    failure
                                )
                            }
                        }
                    return@forEach
                }
                if (!contactState.isProvisioningEligible) {
                    log.info { "Contact $contactId gets no mailbox: ${contactState.ineligibleReason}" }
                    return@forEach
                }

                val current = mailboxRouteRepository.localForContact(contactId).getOrThrow()
                // Only the signed node directory can retire an old mailbox. A previous installation's capability cannot retrieve from
                // a newly installed server, even if its public hostname is the same.
                val retired = current != null && current.isRetiredFrom(availableNodes)
                // Contacts still deliver to the old address of a moved node until a new route is shared.
                val moved = current != null && current.hasMovedIn(availableNodes)
                if (current?.revocationPending == true && !retired) {
                    log.info { "Contact $contactId gets no new mailbox yet: revoking its old one is still pending" }
                    return@forEach
                }
                val credential =
                    if (
                        current != null && !retired && !moved &&
                        current.deliveryRoute.expiresAtEpochMilliseconds > now + RENEWAL_WINDOW_MILLISECONDS
                    ) {
                        current
                    } else {
                        credentialFactory
                            .create(
                                contactId = contactId,
                                nodeId = node.nodeId,
                                routeEndpoint = checkNotNull(node.mailboxRouteEndpoint),
                                accessEndpoint = checkNotNull(node.mailboxAccessEndpoint),
                                sequence = maxOf((current?.deliveryRoute?.sequence ?: -1L) + 1L, now),
                                expiresAtEpochMilliseconds = now + ROUTE_LIFETIME_MILLISECONDS
                            ).also { replacement ->
                                replaceCredential(contactId, current, replacement, retired)
                                provisioned += 1
                            }
                    }

                val queued =
                    protocolOutbox
                        .enqueue(
                            contactId = contactId,
                            packet =
                                MailboxRoutePacket(
                                    packetId = "mailbox-route-${credential.deliveryRoute.routeId}-$ROUTE_PACKET_GENERATION",
                                    deliveryRoute = credential.deliveryRoute
                                )
                        ).getOrThrow()
                log.info { "Mailbox route for contact $contactId: ${queued.packetId.take(20)}… is ${queued.status}" }
            }
            provisioned
        }

    private suspend fun resolveMailboxNodes(): List<NodeEndpoint> =
        nodeEndpointResolver
            .resolve(localRoutingIdSource.getLocalRoutingId().getOrThrow(), forceRefresh = true)
            .getOrThrow()
            .filter { node ->
                node.mailboxRouteEndpoint != null && node.mailboxAccessEndpoint != null
            }.also { nodes -> check(nodes.isNotEmpty()) { "No mailbox-capable node is available" } }

    // A node keeps its ID when its address changes (e.g. a new public IP of the server). The
    // verified directory has the current address; the saved mailboxes are reached there.
    private suspend fun followMovedNodes(availableNodes: List<NodeEndpoint>) {
        mailboxRouteRepository.allLocal().getOrThrow().forEach { credential ->
            movedAccessEndpoint(credential, availableNodes)?.let { accessEndpoint ->
                mailboxRouteRepository.saveLocal(credential.copy(accessEndpoint = accessEndpoint)).getOrThrow()
            }
        }
        mailboxRouteRepository.allRetiring().getOrThrow().forEach { credential ->
            movedAccessEndpoint(credential, availableNodes)?.let { accessEndpoint ->
                mailboxRouteRepository.saveRetiring(credential.copy(accessEndpoint = accessEndpoint)).getOrThrow()
            }
        }
    }

    private fun movedAccessEndpoint(credential: LocalMailboxCredential, availableNodes: List<NodeEndpoint>): String? =
        availableNodes
            .firstOrNull { node -> node.nodeId == credential.deliveryRoute.nodeId }
            ?.mailboxAccessEndpoint
            ?.takeIf { accessEndpoint -> accessEndpoint != credential.accessEndpoint }

    /**
     * A retiring mailbox is revoked only after it expired, and only once the pending synchronization emptied it
     * (or it stayed expired for [RETIRING_GRACE_MILLISECONDS]): the node deletes stored envelopes together with
     * the mailbox. A mailbox whose node left the signed directory is dropped without a revocation, like a current
     * one. A failed revocation while the node is unreachable is retried by the next provisioning; any other failure
     * drops the local copy, the node expires the mailbox on its own.
     */
    private suspend fun revokeExpiredRetiringMailboxes(now: Long, availableNodes: List<NodeEndpoint>) {
        mailboxRouteRepository
            .allRetiring()
            .getOrThrow()
            .filter { credential ->
                !credential.revocationPending && credential.deliveryRoute.expiresAtEpochMilliseconds <= now
            }.forEach { credential ->
                if (credential.isRetiredFrom(availableNodes)) {
                    mailboxRouteRepository.deleteRetiring(credential.deliveryRoute.routeId).getOrThrow()
                    return@forEach
                }
                if (credential.stillHoldsEnvelopes(now)) return@forEach
                mailboxRepository.revoke(credential)
                    .onSuccess { mailboxRouteRepository.deleteRetiring(credential.deliveryRoute.routeId).getOrThrow() }
                    .onFailure { failure ->
                        if (failure is CancellationException) throw failure
                        if (failure.isRecoverableConnectivityFailure()) return@onFailure
                        SparrowLog.diagnostic(
                            "MailboxRouteProvisioner",
                            "Expired mailbox of ${credential.contactId} could not be revoked",
                            failure
                        )
                        mailboxRouteRepository.deleteRetiring(credential.deliveryRoute.routeId).getOrThrow()
                    }
            }
    }

    /** Envelopes still wait in the expired mailbox and the grace period is not over: synchronize them first. */
    private suspend fun LocalMailboxCredential.stillHoldsEnvelopes(now: Long): Boolean {
        if (deliveryRoute.expiresAtEpochMilliseconds + RETIRING_GRACE_MILLISECONDS <= now) return false
        val pending = mailboxRepository.pending(this).getOrElse { failure ->
            if (failure is CancellationException) throw failure
            // An unreachable node may still hold envelopes; anything else is left to the revocation.
            return failure.isRecoverableConnectivityFailure()
        }
        return pending.isNotEmpty()
    }

    private suspend fun replaceCredential(
        contactId: String,
        current: LocalMailboxCredential?,
        replacement: LocalMailboxCredential,
        retired: Boolean
    ) {
        if (current != null && retired) {
            // A node also leaves the directory for a short restart. Its mailbox stays readable as a retiring one, so
            // the envelopes put there before the contact learned the new route still arrive once the node is back; a
            // node installed anew answers that the mailbox is gone, and the synchronizer drops it then.
            log.info {
                "Mailbox of contact $contactId moves from node ${current.deliveryRoute.nodeId.take(8)}, which left the directory, " +
                    "to ${replacement.deliveryRoute.nodeId.take(8)}; the old one stays readable"
            }
        }
        // The old mailbox may still hold envelopes, and the contact keeps sending to it until the queued route
        // packet arrived. It stays readable as a retiring mailbox and is revoked only after its expiry.
        val saved =
            if (current != null) {
                mailboxRouteRepository.retireLocal(current, replacement)
            } else {
                mailboxRouteRepository.saveLocal(replacement)
            }
        saved.getOrElse { persistenceError ->
            mailboxRepository.revoke(replacement)
                .onFailure { failure ->
                    SparrowLog.diagnostic("MailboxRouteProvisioner", "Mailbox replacement cleanup failed for $contactId", failure)
                }
            throw persistenceError
        }
    }

    private companion object {
        const val ROUTE_LIFETIME_MILLISECONDS = 30L * 24L * 60L * 60L * 1_000L

        /**
         * Part of the route packet's ID, so every route is sent once more when it changes. Generation 2: contacts
         * rejected routes before their identity was verified; they accept them after the handshake now. Generation 3:
         * sent once more to follow the route to the contact in the log.
         */
        const val ROUTE_PACKET_GENERATION = 3
        const val RENEWAL_WINDOW_MILLISECONDS = 3L * 24L * 60L * 60L * 1_000L
        const val RETIRING_GRACE_MILLISECONDS = 7L * 24L * 60L * 60L * 1_000L
    }
}

/** The node of this mailbox is still in the directory, but under another route address. */
internal fun LocalMailboxCredential.hasMovedIn(availableNodes: List<NodeEndpoint>): Boolean =
    availableNodes.any { node ->
        node.nodeId == deliveryRoute.nodeId &&
            node.mailboxRouteEndpoint != null &&
            node.mailboxRouteEndpoint != deliveryRoute.nodeEndpoint
    }

/** Do not discard a mailbox merely because its original node is temporarily unreachable. */
internal fun LocalMailboxCredential.isRetiredFrom(availableNodes: List<NodeEndpoint>): Boolean =
    availableNodes.isNotEmpty() && availableNodes.none { node -> node.nodeId == deliveryRoute.nodeId }
